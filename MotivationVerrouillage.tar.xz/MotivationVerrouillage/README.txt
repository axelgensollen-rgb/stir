MOTIVATION VERROUILLAGE — Android / Samsung Galaxy S24
=====================================================

QU'EST-CE QUE C'EST ?
Application Android native GRATUITE, sans publicité, sans connexion ni serveur.
120 citations en français (60 Motivation, 20 Argent, 20 Sport, 20 citations célèbres) ; trois ambiances (Nuit / Forêt / Prune).
Thèmes sélectionnables depuis l’application : Tous, Motivation, Argent et ambition, Sport et discipline, Citations célèbres.
Les citations célèbres affichent le nom de leur auteur ou « Proverbe ».
Le fond d'écran de VERROUILLAGE change environ une fois par jour.
Le fond d'écran d'accueil reste inchangé.

INSTALLATION POUR LA PREMIÈRE FOIS (sur Windows)
1. Installer Android Studio depuis https://developer.android.com/studio
2. Décompresser ce dossier.
3. Ouvrir Android Studio > Open > sélectionner le dossier MotivationVerrouillage.
4. Accepter l'installation des outils SDK / Gradle si demandé (internet requis).
5. Menu Build > Generate App Bundles or APKs > Build APK(s).
6. Le fichier APK se trouve dans app/build/outputs/apk/debug/app-debug.apk.
7. Copier l'APK sur le Samsung S24, ouvrir le fichier et autoriser l'installation
   depuis la source utilisée SI Android le demande.
8. Ouvrir « Motivation Verrouillage », puis toucher « Activer la citation quotidienne ».
9. Verrouiller le téléphone : la phrase sera sur le fond d'écran verrouillé.

SI ANDROID STUDIO DEMANDE UNE VERSION DE GRADLE
- Android Gradle Plugin : 8.9.2
- Gradle : 8.11.1 (ou version prise en charge par AGP)
- JDK : 17 (Android Studio propose une installation intégrée)
- SDK Android : 35

IMPORTANT
- Un APK directement installable n'est PAS fourni dans cette archive : c'est un projet
  source à compiler sur votre PC via Android Studio.
- Sur certains Samsung, le système peut retarder les alarmes à cause des économies
  d'énergie ; le changement reprend à l'ouverture de l'application.
- Android peut ne pas autoriser une application à remplacer certains fonds d'écran
  verrouillés personnalisés ou gérés par d'autres fonctionnalités.
- L'application remplace le fond de verrouillage existant, qu'elle ne peut pas récupérer.
- Pour un déclenchement plus fiable : Paramètres > Applications > Motivation Verrouillage
  > Batterie > Non restreint (si cette option est affichée).
- Le changement de couleur nécessite de toucher « Changer la citation maintenant »
  pour appliquer la nouvelle palette immédiatement.
- Aucune permission d'accès aux photos, contacts ou réseau n'est utilisée.

CONTENU
- Code source Java + configuration Gradle.
- Pas de bibliothèque Android tierce nécessaire.
- La rotation quotidienne utilise AlarmManager (alarme inexacte sans permission spéciale).

Cette archive contient du code destiné à être compilé ; la compilation et les tests
sur Samsung S24 n'ont pas été effectués dans l'environnement de génération.

CITATIONS CONNUES : vérification effectuée pour plusieurs passages historiques
(La Fontaine, Pascal, Voltaire, Descartes, Corneille). Quelques formules
sont des proverbes, indiqués comme tels ; une attribution contestable n’est pas inventée.
