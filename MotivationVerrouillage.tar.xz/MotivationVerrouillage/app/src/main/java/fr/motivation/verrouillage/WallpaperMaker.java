package fr.motivation.verrouillage;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.TextPaint;
import java.util.ArrayList;
import java.util.List;

final class WallpaperMaker {
    static final int WIDTH = 1080;
    static final int HEIGHT = 2340;

    private WallpaperMaker() { }

    static Bitmap make(Quotes.Quote quote, int theme) {
        Bitmap bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        int[] topColors = { Color.rgb(8, 16, 28), Color.rgb(9, 28, 29), Color.rgb(21, 18, 29) };
        int[] bottomColors = { Color.rgb(29, 34, 47), Color.rgb(11, 56, 57), Color.rgb(45, 29, 45) };
        int[] accents = { Color.rgb(207, 186, 148), Color.rgb(154, 220, 191), Color.rgb(207, 174, 208) };
        int t = Math.max(0, Math.min(theme, topColors.length - 1));

        p.setShader(new LinearGradient(0, 0, WIDTH, HEIGHT, topColors[t], bottomColors[t], Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, WIDTH, HEIGHT, p);
        p.setShader(null);

        // Soft decorative glow; keeps upper portion unobstructed for the OS clock.
        p.setColor(withAlpha(accents[t], 25));
        canvas.drawCircle(920, 1360, 420, p);
        p.setColor(withAlpha(accents[t], 13));
        canvas.drawCircle(20, 1900, 520, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2);
        p.setColor(withAlpha(accents[t], 24));
        canvas.drawCircle(900, 1300, 570, p);
        canvas.drawCircle(900, 1300, 680, p);
        p.setStyle(Paint.Style.FILL);

        // Decorative line at the beginning of the quote area.
        p.setColor(accents[t]);
        p.setStrokeWidth(4f);
        canvas.drawLine(468, 1038, 612, 1038, p);

        TextPaint small = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        small.setColor(accents[t]);
        small.setTextSize(29);
        small.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        small.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("PENSÉE DU JOUR", WIDTH / 2f, 1111, small);

        TextPaint main = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        main.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        main.setColor(Color.WHITE);
        main.setTextAlign(Paint.Align.CENTER);

        float size = 75f;
        List<String> lines = new ArrayList<>();
        while (size >= 46f) {
            main.setTextSize(size);
            lines = wrap(quote.text, main, 890f);
            if (lines.size() <= 5) break;
            size -= 4f;
        }
        float leading = size * 1.38f;
        float centerY = 1430f;
        float firstBaseline = centerY - (lines.size() - 1) * leading / 2f + size * 0.32f;
        for (int i = 0; i < lines.size(); i++) {
            canvas.drawText(lines.get(i), WIDTH / 2f, firstBaseline + leading * i, main);
        }

        // Affiche l'auteur pour les citations célèbres vérifiées, pas d'attribution inventée.
        if (!quote.author.isEmpty()) {
            small.setColor(accents[t]);
            small.setTextSize(34);
            canvas.drawText("— " + quote.author, WIDTH / 2f, 1805, small);
        }

        Paint separator = new Paint(Paint.ANTI_ALIAS_FLAG);
        separator.setColor(withAlpha(accents[t], 140));
        separator.setStrokeWidth(2.5f);
        canvas.drawLine(460, 1898, 620, 1898, separator);
        small.setColor(Color.argb(178, 255, 255, 255));
        small.setTextSize(23);
        canvas.drawText("UN JOUR À LA FOIS", WIDTH / 2f, 1970, small);
        return bitmap;
    }

    private static List<String> wrap(String text, TextPaint paint, float maxWidth) {
        List<String> lines = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        for (String word : text.trim().split("\\s+")) {
            String combined = current.length() == 0 ? word : current + " " + word;
            if (paint.measureText(combined) <= maxWidth || current.length() == 0) {
                current = new StringBuilder(combined);
            } else {
                lines.add(current.toString());
                current = new StringBuilder(word);
            }
        }
        if (current.length() > 0) lines.add(current.toString());
        return lines;
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }
}
