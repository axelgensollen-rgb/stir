package fr.motivation.verrouillage;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

final class WallpaperUpdater {
    static final String PREFS = "motivation_options";
    static final String KEY_ENABLED = "enabled";
    static final String KEY_THEME = "theme";
    static final String KEY_CATEGORY = "category";
    static final String KEY_OFFSET = "offset";
    static final String KEY_APPLIED_DAY = "applied_day";
    private static final int ALARM_ID = 2044;

    private WallpaperUpdater() { }

    static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static Quotes.Quote quoteForToday(Context context) {
        SharedPreferences p = prefs(context);
        long day = LocalDate.now().toEpochDay();
        int offset = p.getInt(KEY_OFFSET, 0);
        int category = p.getInt(KEY_CATEGORY, 0);
        return Quotes.choose(day, offset, category);
    }

    static void apply(Context context) throws Exception {
        Context app = context.getApplicationContext();
        WallpaperManager manager = WallpaperManager.getInstance(app);
        if (!manager.isWallpaperSupported() || !manager.isSetWallpaperAllowed()) {
            throw new IllegalStateException("La modification du fond d'écran n'est pas autorisée sur cet appareil.");
        }
        Bitmap wallpaper = WallpaperMaker.make(quoteForToday(app), prefs(app).getInt(KEY_THEME, 0));
        try {
            // FLAG_LOCK modifies ONLY the lock screen, never the home screen.
            manager.setBitmap(wallpaper, null, false, WallpaperManager.FLAG_LOCK);
            prefs(app).edit().putLong(KEY_APPLIED_DAY, LocalDate.now().toEpochDay()).apply();
        } finally {
            wallpaper.recycle();
        }
    }

    static void applyOnlyIfNeeded(Context context) throws Exception {
        long today = LocalDate.now().toEpochDay();
        if (prefs(context).getBoolean(KEY_ENABLED, false)
                && prefs(context).getLong(KEY_APPLIED_DAY, Long.MIN_VALUE) != today) {
            apply(context);
        }
    }

    static void schedule(Context context) {
        Context app = context.getApplicationContext();
        AlarmManager alarm = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        PendingIntent pendingIntent = getPendingIntent(app);
        alarm.cancel(pendingIntent);
        if (!prefs(app).getBoolean(KEY_ENABLED, false)) return;

        // Inexact, permission-free alarm: Android may postpone delivery due to Doze.
        Calendar next = Calendar.getInstance();
        next.add(Calendar.DAY_OF_YEAR, 1);
        next.set(Calendar.HOUR_OF_DAY, 0);
        next.set(Calendar.MINUTE, 5);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY, pendingIntent);
    }

    private static PendingIntent getPendingIntent(Context context) {
        Intent intent = new Intent(context, UpdateReceiver.class);
        return PendingIntent.getBroadcast(context, ALARM_ID, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
