package fr.motivation.verrouillage;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private final int background = Color.rgb(12, 18, 29);
    private final int white = Color.rgb(246, 245, 242);
    private final int muted = Color.rgb(183, 193, 202);
    private final int accent = Color.rgb(217, 190, 145);
    private final int dpPadding = 20;

    private ImageView preview;
    private TextView status;
    private Button toggle;
    private Button themeButton;
    private Button categoryButton;
    private boolean busy = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(background);
        buildUi();
        refreshPreview();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (WallpaperUpdater.prefs(this).getBoolean(WallpaperUpdater.KEY_ENABLED, false)) {
            new Thread(() -> {
                try { WallpaperUpdater.applyOnlyIfNeeded(this); }
                catch (Exception ignored) { }
            }, "motivation-foreground-check").start();
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(background);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setGravity(Gravity.CENTER_HORIZONTAL);
        main.setPadding(dp(dpPadding), dp(24), dp(dpPadding), dp(40));
        scroll.addView(main);

        if (Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets system = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                main.setPadding(dp(dpPadding), dp(24) + system.top,
                    dp(dpPadding), dp(40) + system.bottom);
                return insets;
            });
        }

        TextView kicker = label("TON RENDEZ-VOUS AVEC TOI-MÊME", 11, accent, true);
        kicker.setGravity(Gravity.CENTER);
        main.addView(kicker);

        TextView title = label("Une citation. Chaque jour.", 29, white, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(14), 0, dp(8));
        main.addView(title);

        TextView subtitle = label("Directement sur l'écran de verrouillage de ton Samsung. Sans compte, sans publicité.", 14, muted, false);
        subtitle.setGravity(Gravity.CENTER);
        main.addView(subtitle);

        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams photoParams = new LinearLayout.LayoutParams(dp(220), dp(450));
        photoParams.gravity = Gravity.CENTER_HORIZONTAL;
        photoParams.topMargin = dp(24);
        photoParams.bottomMargin = dp(12);
        main.addView(preview, photoParams);

        status = label("", 14, muted, false);
        status.setGravity(Gravity.CENTER);
        main.addView(status);

        toggle = createButton(main, "Activer la citation quotidienne", true);
        toggle.setOnClickListener(v -> {
            boolean enabled = WallpaperUpdater.prefs(this).getBoolean(WallpaperUpdater.KEY_ENABLED, false);
            if (!enabled) {
                WallpaperUpdater.prefs(this).edit().putBoolean(WallpaperUpdater.KEY_ENABLED, true).apply();
                WallpaperUpdater.schedule(this);
                applyAndUpdate("Activation réussie. La citation changera chaque jour.");
            } else {
                WallpaperUpdater.prefs(this).edit().putBoolean(WallpaperUpdater.KEY_ENABLED, false).apply();
                WallpaperUpdater.schedule(this);
                updateStatus();
            }
        });

        categoryButton = createButton(main, "Thèmes : Tous les thèmes", false);
        categoryButton.setOnClickListener(v -> {
            SharedPreferences p = WallpaperUpdater.prefs(this);
            p.edit().putInt(WallpaperUpdater.KEY_CATEGORY,
                    (p.getInt(WallpaperUpdater.KEY_CATEGORY, 0) + 1) % Quotes.CATEGORY_NAMES.length).apply();
            refreshPreview();
            applyIfActive();
        });

        Button nextButton = createButton(main, "Changer la citation maintenant", false);
        nextButton.setOnClickListener(v -> {
            SharedPreferences p = WallpaperUpdater.prefs(this);
            p.edit().putInt(WallpaperUpdater.KEY_OFFSET,
                    p.getInt(WallpaperUpdater.KEY_OFFSET, 0) + 1).apply();
            refreshPreview();
            applyAndUpdate("Nouvelle citation appliquée à l'écran verrouillé.");
        });

        themeButton = createButton(main, "Couleur : Nuit", false);
        themeButton.setOnClickListener(v -> {
            SharedPreferences p = WallpaperUpdater.prefs(this);
            p.edit().putInt(WallpaperUpdater.KEY_THEME,
                    (p.getInt(WallpaperUpdater.KEY_THEME, 0) + 1) % 3).apply();
            refreshPreview();
            applyIfActive();
        });

        TextView note = label("L'application ne touche pas au fond d'écran d'accueil. Android peut retarder légèrement le changement quotidien pour économiser la batterie.",
                12, muted, false);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(20), 0, 0);
        main.addView(note);

        setContentView(scroll);
        updateStatus();
    }

    private void applyIfActive() {
        if (WallpaperUpdater.prefs(this).getBoolean(WallpaperUpdater.KEY_ENABLED, false)) {
            applyAndUpdate("Nouveau thème appliqué à l’écran verrouillé.");
        } else {
            updateStatus();
        }
    }

    private void applyAndUpdate(String message) {
        if (busy) return;
        busy = true;
        toggle.setEnabled(false);
        status.setText("Application du fond d'écran…");
        new Thread(() -> {
            String result;
            boolean success = true;
            try {
                WallpaperUpdater.apply(this);
                result = message;
            } catch (Exception e) {
                success = false;
                result = "Impossible de changer le fond : " + e.getMessage();
            }
            final boolean ok = success;
            final String text = result;
            runOnUiThread(() -> {
                busy = false;
                toggle.setEnabled(true);
                updateStatus();
                Toast.makeText(this, text, Toast.LENGTH_LONG).show();
                if (!ok) status.setText(text);
            });
        }, "motivation-apply").start();
    }

    private void refreshPreview() {
        Bitmap bitmap = WallpaperMaker.make(WallpaperUpdater.quoteForToday(this),
                WallpaperUpdater.prefs(this).getInt(WallpaperUpdater.KEY_THEME, 0));
        preview.setImageBitmap(bitmap);
        int style = WallpaperUpdater.prefs(this).getInt(WallpaperUpdater.KEY_THEME, 0);
        themeButton.setText("Couleur : " + new String[]{"Nuit", "Forêt", "Prune"}[style]);
        int category = WallpaperUpdater.prefs(this).getInt(WallpaperUpdater.KEY_CATEGORY, 0);
        if (category < 0 || category >= Quotes.CATEGORY_NAMES.length) category = 0;
        categoryButton.setText("Thèmes : " + Quotes.CATEGORY_NAMES[category]);
    }

    private void updateStatus() {
        boolean enabled = WallpaperUpdater.prefs(this).getBoolean(WallpaperUpdater.KEY_ENABLED, false);
        status.setText(enabled ? "● Changement quotidien activé" : "○ Changement quotidien désactivé");
        toggle.setText(enabled ? "Désactiver le changement quotidien" : "Activer la citation quotidienne");
    }

    private Button createButton(LinearLayout parent, String text, boolean prominent) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(text);
        button.setTextColor(prominent ? Color.rgb(18, 23, 33) : white);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(prominent ? accent : Color.rgb(35, 44, 58));
        bg.setCornerRadius(dp(16));
        button.setBackground(bg);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        params.topMargin = dp(12);
        parent.addView(button, params);
        return button;
    }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private int dp(float dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }
}
