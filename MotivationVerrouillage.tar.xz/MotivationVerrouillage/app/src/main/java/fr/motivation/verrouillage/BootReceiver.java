package fr.motivation.verrouillage;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (WallpaperUpdater.prefs(context).getBoolean(WallpaperUpdater.KEY_ENABLED, false)) {
            WallpaperUpdater.schedule(context);
        }
    }
}
