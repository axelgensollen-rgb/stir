package fr.motivation.verrouillage;

import java.util.ArrayList;
import java.util.List;

final class Quotes {
    static final String[] CATEGORY_NAMES = {
        "Tous les thèmes", "Motivation", "Argent et ambition", "Sport et discipline", "Citations célèbres"
    };

    static final class Quote {
        final String text;
        final String author;
        final int category;

        Quote(String text, String author, int category) {
            this.text = text;
            this.author = author;
            this.category = category;
        }
    }

    private Quotes() { }

    static final Quote[] ALL = {
        new Quote("Choisis les personnes qui te choisissent.", "", 1),
        new Quote("La discipline construit ce que la motivation commence.", "", 1),
        new Quote("Chaque jour compte. Même les jours difficiles.", "", 1),
        new Quote("Tu n'as pas besoin d'être parfait pour avancer.", "", 1),
        new Quote("Ton avenir se construit dans ce que tu fais aujourd'hui.", "", 1),
        new Quote("Le courage, c'est d'agir malgré le doute.", "", 1),
        new Quote("Tu progresses chaque fois que tu refuses d'abandonner.", "", 1),
        new Quote("N'attends pas le bon moment. Crée-le.", "", 1),
        new Quote("La constance finit par dépasser le talent.", "", 1),
        new Quote("Protège ta paix. Investis ton énergie au bon endroit.", "", 1),
        new Quote("L'action transforme les intentions en résultats.", "", 1),
        new Quote("Sois fier du chemin, pas seulement du résultat.", "", 1),
        new Quote("Tu peux avancer lentement, mais continue d'avancer.", "", 1),
        new Quote("Ne négocie pas avec les excuses.", "", 1),
        new Quote("Ce que tu répètes devient ce que tu es.", "", 1),
        new Quote("Reste fidèle à tes valeurs, pas à tes peurs.", "", 1),
        new Quote("La confiance se construit avec les promesses tenues à soi-même.", "", 1),
        new Quote("Tout changement commence par une décision.", "", 1),
        new Quote("Tu n'as pas à convaincre ceux qui ne te voient pas.", "", 1),
        new Quote("La patience aussi est une forme de force.", "", 1),
        new Quote("Fais aujourd'hui ce que ton futur toi appréciera.", "", 1),
        new Quote("Échouer n'est pas reculer. Renoncer, si.", "", 1),
        new Quote("Ta valeur ne dépend pas du regard des autres.", "", 1),
        new Quote("Une petite victoire répétée devient un grand changement.", "", 1),
        new Quote("Avance avec intention, pas avec précipitation.", "", 1),
        new Quote("Donne de ton énergie à ce qui te fait grandir.", "", 1),
        new Quote("Reste humble dans la victoire, solide dans l'épreuve.", "", 1),
        new Quote("Il n'y a pas de progrès sans inconfort.", "", 1),
        new Quote("Ton rythme n'a pas à ressembler à celui des autres.", "", 1),
        new Quote("Deviens la personne sur qui tu peux compter.", "", 1),
        new Quote("Chaque effort est une preuve que tu y crois encore.", "", 1),
        new Quote("La vie change quand tes habitudes changent.", "", 1),
        new Quote("Le respect de soi commence par des limites claires.", "", 1),
        new Quote("Fais moins de promesses et plus de progrès.", "", 1),
        new Quote("N'oublie pas pourquoi tu as commencé.", "", 1),
        new Quote("Tes résultats suivent tes actions, pas tes envies.", "", 1),
        new Quote("Tu n'as rien à prouver, mais tout à construire.", "", 1),
        new Quote("Apprends du passé. Ne t'y installe pas.", "", 1),
        new Quote("Construis en silence. Laisse parler tes actes.", "", 1),
        new Quote("La meilleure revanche, c'est une vie qui te ressemble.", "", 1),
        new Quote("Ce qui mérite ta place mérite aussi ton effort.", "", 1),
        new Quote("Prends soin de ce qui compte vraiment.", "", 1),
        new Quote("Si tu veux changer ta vie, change une habitude.", "", 1),
        new Quote("L'estime de soi grandit à chaque acte de courage.", "", 1),
        new Quote("Il reste toujours un pas que tu peux faire.", "", 1),
        new Quote("La clarté vient souvent après le premier pas.", "", 1),
        new Quote("Ne laisse pas une mauvaise journée définir ton parcours.", "", 1),
        new Quote("Le plus important, c'est ce que tu fais ensuite.", "", 1),
        new Quote("Sois exigeant avec tes efforts, bienveillant avec toi-même.", "", 1),
        new Quote("Ce que tu nourris prend de la place dans ta vie.", "", 1),
        new Quote("Cherche la progression, pas l'approbation.", "", 1),
        new Quote("Une décision courageuse peut changer toute une trajectoire.", "", 1),
        new Quote("Ta discipline d'aujourd'hui est ta liberté de demain.", "", 1),
        new Quote("Le temps passe de toute façon. Fais-le compter.", "", 1),
        new Quote("La persévérance, c'est recommencer intelligemment.", "", 1),
        new Quote("Tu mérites des relations où l'effort est réciproque.", "", 1),
        new Quote("Ne confonds pas attendre et construire.", "", 1),
        new Quote("Choisis ton cap, puis avance avec régularité.", "", 1),
        new Quote("Tu peux être discret et pourtant déterminé.", "", 1),
        new Quote("Rappelle-toi : tu as déjà surmonté des jours difficiles.", "", 1),
        new Quote("Construis des actifs, pas seulement un salaire.", "", 2),
        new Quote("L’argent se gère avant de se dépenser.", "", 2),
        new Quote("Ta liberté financière commence avec tes habitudes.", "", 2),
        new Quote("Chaque euro doit avoir une mission.", "", 2),
        new Quote("La richesse se construit par des décisions répétées.", "", 2),
        new Quote("La patience est un avantage en investissement.", "", 2),
        new Quote("Fais travailler ton capital avec méthode.", "", 2),
        new Quote("N’achète pas pour impressionner les autres.", "", 2),
        new Quote("Apprends à investir avant de chercher à gagner vite.", "", 2),
        new Quote("La maîtrise du risque précède la recherche du gain.", "", 2),
        new Quote("Un objectif sans plan n’est qu’une envie.", "", 2),
        new Quote("Ce que tu épargnes aujourd’hui peut créer tes choix de demain.", "", 2),
        new Quote("Préfère les progrès durables aux promesses faciles.", "", 2),
        new Quote("Le vrai luxe, c’est de choisir son temps.", "", 2),
        new Quote("La constance vaut plus que les coups de chance.", "", 2),
        new Quote("Préserve ton capital pour pouvoir saisir les opportunités.", "", 2),
        new Quote("N’investis jamais sous le coup de l’émotion.", "", 2),
        new Quote("Pense en années, pas seulement en journées.", "", 2),
        new Quote("Chaque compétence développée augmente tes possibilités.", "", 2),
        new Quote("La discipline financière offre plus de liberté.", "", 2),
        new Quote("La dernière répétition commence dans la tête.", "", 3),
        new Quote("Ta progression se joue aussi les jours sans motivation.", "", 3),
        new Quote("Chaque séance est un rendez-vous avec tes objectifs.", "", 3),
        new Quote("Ce n’est pas la perfection qui compte, c’est la régularité.", "", 3),
        new Quote("L’effort est quotidien, le progrès est cumulatif.", "", 3),
        new Quote("Sois plus fort que tes excuses.", "", 3),
        new Quote("Entraîne-toi pour progresser, pas pour te comparer.", "", 3),
        new Quote("Une répétition de qualité vaut mieux qu’une répétition bâclée.", "", 3),
        new Quote("La récupération fait partie de l’entraînement.", "", 3),
        new Quote("Reste patient, même quand les résultats tardent.", "", 3),
        new Quote("La force se construit une séance après l’autre.", "", 3),
        new Quote("La discipline transforme une envie en habitude.", "", 3),
        new Quote("Tu n’as pas besoin d’être motivé pour commencer.", "", 3),
        new Quote("Répète les bons gestes jusqu’à ce qu’ils deviennent naturels.", "", 3),
        new Quote("Le progrès se mesure sur la durée.", "", 3),
        new Quote("Le respect de ton corps fait partie de la performance.", "", 3),
        new Quote("La constance bat les efforts irréguliers.", "", 3),
        new Quote("Chaque pas compte, même le plus petit.", "", 3),
        new Quote("La régularité fait la différence.", "", 3),
        new Quote("Prépare ta séance, puis donne le meilleur de toi-même.", "", 3),
        new Quote("Patience et longueur de temps font plus que force ni que rage.", "Jean de La Fontaine", 4),
        new Quote("Rien ne sert de courir ; il faut partir à point.", "Jean de La Fontaine", 4),
        new Quote("Aide-toi, le Ciel t’aidera.", "Jean de La Fontaine", 4),
        new Quote("Il faut cultiver notre jardin.", "Voltaire", 4),
        new Quote("Le cœur a ses raisons que la raison ne connaît point.", "Blaise Pascal", 4),
        new Quote("Je pense, donc je suis.", "René Descartes", 4),
        new Quote("La valeur n’attend point le nombre des années.", "Pierre Corneille", 4),
        new Quote("Un seul être vous manque, et tout est dépeuplé.", "Alphonse de Lamartine", 4),
        new Quote("Le temps, c’est de l’argent.", "Benjamin Franklin", 4),
        new Quote("Ce qui ne me tue pas me rend plus fort.", "Friedrich Nietzsche", 4),
        new Quote("Le travail éloigne de nous trois grands maux : l’ennui, le vice et le besoin.", "Voltaire", 4),
        new Quote("La fortune sourit aux audacieux.", "Proverbe latin", 4),
        new Quote("On n’est jamais mieux servi que par soi-même.", "Proverbe", 4),
        new Quote("C’est en forgeant qu’on devient forgeron.", "Proverbe", 4),
        new Quote("Vouloir, c’est pouvoir.", "Proverbe", 4),
        new Quote("Petit à petit, l’oiseau fait son nid.", "Proverbe", 4),
        new Quote("Après la pluie, le beau temps.", "Proverbe", 4),
        new Quote("L’union fait la force.", "Proverbe", 4),
        new Quote("À cœur vaillant rien d’impossible.", "Proverbe", 4),
        new Quote("Ne remets pas à demain ce que tu peux faire aujourd’hui.", "Proverbe", 4)
    };

    static Quote choose(long day, int offset, int chosenCategory) {
        long sequence = day + offset;
        int category = chosenCategory;
        if (category < 1 || category >= CATEGORY_NAMES.length) {
            category = 1 + (int) Math.floorMod(sequence, 4L);
        }
        List<Quote> candidates = new ArrayList<>();
        for (Quote quote : ALL) {
            if (quote.category == category) candidates.add(quote);
        }
        // En mode mélange, alternance équilibrée entre les quatre thèmes.
        long rotation = chosenCategory == 0 ? Math.floorDiv(sequence, 4L) : sequence;
        int index = (int) Math.floorMod(rotation, (long) candidates.size());
        return candidates.get(index);
    }
}
