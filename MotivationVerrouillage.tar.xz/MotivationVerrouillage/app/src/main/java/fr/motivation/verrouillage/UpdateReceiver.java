package fr.motivation.verrouillage;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class UpdateReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        PendingResult result = goAsync();
        Context app = context.getApplicationContext();
        new Thread(() -> {
            try {
                WallpaperUpdater.applyOnlyIfNeeded(app);
            } catch (Exception ignored) {
                // The user can open the app to see an actionable error message.
            } finally {
                result.finish();
            }
        }, "motivation-update").start();
    }
}
